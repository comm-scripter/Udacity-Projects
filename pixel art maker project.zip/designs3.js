// declare variables
const color = document.getElementById('colorPicker');
const table = document.getElementById('pixelCanvas');
const height = document.getElementById('inputHeight').value;
const width = document.getElementById('inputWidth').value;
const sizePicker = document.querySelector("#sizePicker");


sizePicker.addEventListener("submit", function(e) {
    e.preventDefault();
	let height = document.getElementById('inputHeight').value;
	let width = document.getElementById('inputWidth').value;
	table.innerHTML = '';
    makeGrid(height, width);
});

/*
 * @function makeGrid 
 * @param   {number} width is the number of columns in the table
 * @param   {number} height is the number of rows in the table
 * @description takes two numbers (height and width) and creates an html table
 * clicking on cells adds background color
 */

function makeGrid(height, width) {
	for (let i = 0; i < height; i++){
		let row = table.insertRow (i);
		for (let j = 0; j < width; j ++){
			let cell = row.insertCell (j);
			cell.addEventListener('click', (e) => {
				cell.style.backgroundColor = color.value;
			});
		}
	}



}
